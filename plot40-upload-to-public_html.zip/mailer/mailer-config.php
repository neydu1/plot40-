<?php
/* Plot 40 mailer settings — fill these in from cPanel → Email Accounts → your account → "Connect Devices". */

// Secret key: paste this SAME key into the admin portal → Website → Email sending.
define('MAILER_KEY', '5Fhpd8BvAmJ3MbHiENwDVI-jDoV9DXx7r3d4WmnzUKI');

// The cPanel mailbox emails are sent from (create it in cPanel → Email Accounts).
define('MAIL_FROM', 'bookings@plot40apartments.com');
define('MAIL_FROM_NAME', 'Plot 40 Apartments');

// Outgoing (SMTP) server — shown under "Connect Devices" → "Secure SSL/TLS Settings".
define('SMTP_HOST', 'mail.plot40apartments.com');   // leave '' to use the server's built-in PHP mail() instead
define('SMTP_PORT', 465);                     // 465 = SSL (recommended) · 587 = TLS
define('SMTP_SECURE', 'ssl');                 // 'ssl' for port 465 · 'tls' for port 587
define('SMTP_USER', 'bookings@plot40apartments.com');
define('SMTP_PASS', 'the-mailbox-password');
define('SMTP_VERIFY', true);                  // set to false only if your host's mail certificate is self-signed
