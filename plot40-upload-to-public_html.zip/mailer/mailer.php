<?php
/**
 * Plot 40 Apartments — cPanel mail relay
 * The booking backend (Google Apps Script) posts each email here; this script sends it
 * through your cPanel mailbox using SMTP (or PHP mail() if SMTP isn't filled in).
 * Settings live in mailer-config.php in the same folder.
 */
declare(strict_types=1);
require __DIR__ . '/mailer-config.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');

function reply(array $o, int $code = 200): void { http_response_code($code); echo json_encode($o); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['ok' => true, 'service' => 'Plot 40 mailer']);

$in = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($in)) reply(['ok' => false, 'error' => 'bad request'], 400);
if (MAILER_KEY === '' || !hash_equals(MAILER_KEY, (string)($in['key'] ?? ''))) reply(['ok' => false, 'error' => 'auth'], 403);
if (!empty($in['ping'])) reply(['ok' => true, 'from' => MAIL_FROM, 'via' => SMTP_HOST !== '' ? 'smtp' : 'mail']);

$clean = fn($s) => trim(str_replace(["\r", "\n"], ' ', (string)$s));
$to = array_values(array_filter(array_map('trim', preg_split('/[,;]+/', (string)($in['to'] ?? ''))), fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL)));
$subject = mb_substr($clean($in['subject'] ?? ''), 0, 250);
$html = (string)($in['html'] ?? '');
$replyTo = filter_var($clean($in['replyTo'] ?? ''), FILTER_VALIDATE_EMAIL) ?: '';
$fromName = mb_substr($clean($in['fromName'] ?? MAIL_FROM_NAME), 0, 80) ?: MAIL_FROM_NAME;

if (!$to) reply(['ok' => false, 'error' => 'no valid recipient'], 400);
if (count($to) > 20) reply(['ok' => false, 'error' => 'too many recipients'], 400);
if ($subject === '' || $html === '' || strlen($html) > 300000) reply(['ok' => false, 'error' => 'missing subject or message'], 400);

try {
    $msg = build_message($to, $subject, $html, $replyTo, $fromName);
    if (SMTP_HOST !== '') smtp_send($to, $msg);
    else php_mail($to, $subject, $msg);
    reply(['ok' => true]);
} catch (Throwable $e) {
    reply(['ok' => false, 'error' => $e->getMessage()], 502);
}

/* ---------------- message ---------------- */
function enc(string $s): string { return preg_match('/[^\x20-\x7E]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s; }
function build_message(array $to, string $subject, string $html, string $replyTo, string $fromName): array {
    $domain = substr(strrchr(MAIL_FROM, '@'), 1) ?: 'localhost';
    $boundary = 'p40_' . bin2hex(random_bytes(12));
    $text = html_entity_decode(trim(preg_replace("/\n{3,}/", "\n\n", strip_tags(preg_replace(['#<br\s*/?>#i', '#</(p|div|tr|h\d)>#i'], ["\n", "\n\n"], $html)))), ENT_QUOTES, 'UTF-8');
    $headers = [
        'Date: ' . date('r'),
        'From: ' . enc($fromName) . ' <' . MAIL_FROM . '>',
        'To: ' . implode(', ', $to),
        'Subject: ' . enc($subject),
        'Message-ID: <' . bin2hex(random_bytes(10)) . '@' . $domain . '>',
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
    ];
    if ($replyTo) $headers[] = 'Reply-To: ' . $replyTo;
    $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) .
            "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) .
            "--$boundary--\r\n";
    return ['headers' => $headers, 'body' => $body];
}

/* ---------------- sending ---------------- */
function smtp_send(array $to, array $msg): void {
    $secure = strtolower(SMTP_SECURE);
    $ctx = stream_context_create(['ssl' => ['verify_peer' => SMTP_VERIFY, 'verify_peer_name' => SMTP_VERIFY, 'allow_self_signed' => !SMTP_VERIFY, 'peer_name' => SMTP_HOST]]);
    $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://') . SMTP_HOST . ':' . SMTP_PORT, $errno, $errstr, 20, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new RuntimeException("Couldn't connect to the mail server ($errstr)");
    stream_set_timeout($fp, 25);
    $read = function () use ($fp): string {
        $data = '';
        while (($line = fgets($fp, 1024)) !== false) { $data .= $line; if (strlen($line) < 4 || $line[3] === ' ') break; }
        return $data;
    };
    $cmd = function (?string $c, array $ok, string $label) use ($fp, $read): string {
        if ($c !== null) fwrite($fp, $c . "\r\n");
        $r = $read();
        if (!in_array((int)substr($r, 0, 3), $ok, true)) throw new RuntimeException("Mail server refused $label: " . trim($r));
        return $r;
    };
    $helo = 'EHLO ' . (substr(strrchr(MAIL_FROM, '@'), 1) ?: 'localhost');
    $cmd(null, [220], 'connection');
    $cmd($helo, [250], 'EHLO');
    if ($secure === 'tls') {
        $cmd('STARTTLS', [220], 'STARTTLS');
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Could not start TLS');
        $cmd($helo, [250], 'EHLO');
    }
    $cmd('AUTH LOGIN', [334], 'login');
    $cmd(base64_encode(SMTP_USER), [334], 'username');
    $cmd(base64_encode(SMTP_PASS), [235], 'password (check SMTP_USER / SMTP_PASS)');
    $cmd('MAIL FROM:<' . MAIL_FROM . '>', [250], 'sender');
    foreach ($to as $t) $cmd("RCPT TO:<$t>", [250, 251], "recipient $t");
    $cmd('DATA', [354], 'DATA');
    $data = implode("\r\n", $msg['headers']) . "\r\n\r\n" . $msg['body'];
    $data = preg_replace('/^\./m', '..', str_replace(["\r\n", "\n"], ["\n", "\r\n"], $data));
    fwrite($fp, $data . "\r\n.\r\n");
    $cmd(null, [250], 'message');
    @fwrite($fp, "QUIT\r\n");
    fclose($fp);
}

function php_mail(array $to, string $subject, array $msg): void {
    $headers = array_values(array_filter($msg['headers'], fn($h) => !preg_match('/^(To|Subject):/i', $h)));
    if (!mail(implode(', ', $to), enc($subject), $msg['body'], implode("\r\n", $headers), '-f' . MAIL_FROM))
        throw new RuntimeException('The server could not send the email');
}
