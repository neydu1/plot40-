window.PLOT40_BACKEND_URL = "https://script.google.com/macros/s/AKfycbxMegwG61BXlt8rwPLS1gZ5h02SBQe5ygfLpRej5YBbbLg_F3Rq1kxwbdM4i2aJGbAF/exec";
